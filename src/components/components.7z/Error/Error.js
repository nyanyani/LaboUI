import { ErrorCtx } from "@/states"
import React, { memo, useContext, useEffect, useLayoutEffect, useRef, useState } from "react"
import { ErrorIcon, ErrorItem, ErrorList, ErrorWrapper, NextPage, PrevPage } from "./Error.elements"

function Error(props) {
  const { range: defaultRange = { from: 0, to: 10 } } = props
  // newest error at array head
  const { errors, setCurrError } = useContext(ErrorCtx)
  const [range, setRange] = useState(defaultRange)

  const show = errors.slice(range.from, range.to)

  const ref = useRef()

  useLayoutEffect(() => {
    setRange((prevRange) => {
      const newRange = { from: prevRange.from, to: errors.length }
      if (errors.length - prevRange.to < defaultRange.to && prevRange.from) {
        let offset = 0
        offset = errors.length % defaultRange.to
        if (offset) {
          newRange.from = errors.length - offset
        }
        return newRange
      }
      return prevRange
    })
  }, [defaultRange.to, errors])

  useEffect(() => {
    const wrapper = ref.current
    const handleClear = (e) => {
      const item = e.target.closest("li")
      if (wrapper.contains(item)) {
        setCurrError((prevErrors) => prevErrors.filter((error) => error.id !== item.dataset.errorId))
      }
    }
    wrapper.addEventListener("click", handleClear)

    return () => {
      wrapper.removeEventListener("click", handleClear)
    }
  }, [setCurrError])
  return (
    <ErrorWrapper {...props} ref={ref}>
      <PrevPage
        css={`
          visibility: ${range.from > 0 ? "visible" : "hidden"};
        `}
        disabled={range.from === 0}
        onClick={() => {
          const from = Math.max(0, range.from - defaultRange.to)
          setRange({ from, to: Math.max(range.to - defaultRange.to, from + defaultRange.to) })
        }}
      />
      <ErrorList
        css={`
          margin: ${range.from > 0 && "0 auto 0 0"};
        `}>
        {show.map(({ id, type, message }) => (
          <ErrorItem $direction={props.direction} key={id} data-error={message} data-error-id={id}>
            <ErrorIcon
              css={`
                animation: bounce-in-left 1s ease;
                animation-iteration-count: 1;
              `}>
              <use xlinkHref={`#error-${type}`} />
            </ErrorIcon>
          </ErrorItem>
        ))}
      </ErrorList>
      <NextPage
        css={`
          visibility: ${errors.length > range.to ? "visible" : "hidden"};
        `}
        disabled={range.to === errors.length}
        onClick={() =>
          setRange({
            from: Math.min(range.from + defaultRange.to, errors.length - 1),
            to: Math.min(errors.length, range.to + defaultRange.to),
          })
        }
      />
    </ErrorWrapper>
  )
}

export default memo(Error)
