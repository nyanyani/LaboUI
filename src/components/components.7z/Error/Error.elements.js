import { Arrow, ToolTips } from "@/globalStyles"
import styled from "styled-components"

export const ErrorWrapper = styled.div`
  display: flex;
  flex-basis: 65rem;
  justify-content: space-between;
  align-items: center;
`
export const ErrorList = styled.ul`
  display: flex;
  margin: 0 0 0 auto;
  padding: 0;
  list-style: none;
  justify-content: flex-end;
  align-items: center;
  gap: 1rem;
`

export const ErrorItem = styled.li`
  position: relative;
  z-index: 10;
  width: 5rem;
  height: 5rem;
  cursor: pointer;

  ${ToolTips}
`

ErrorItem.defaultProps = {
  title: "点击消除该提示",
  tipAttr: "data-error",
}

export const ErrorIcon = styled.svg`
  width: 5rem;
  height: 5rem;
`

export { Arrow as PrevPage }

export const NextPage = styled(Arrow)`
  transform: rotate(180deg);
`
