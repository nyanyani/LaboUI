import styled from "styled-components"

import { Link } from "react-router-dom"
import { Button } from "@/globalStyles"

export const Nav = styled.nav`
  display: flex;
  align-items: center;
  height: 9rem;
`

export const NavLogo = styled(Link)`
  display: inline-block;
  cursor: pointer;
  align-items: center;

  img {
    height: 3rem;
  }
`
NavLogo.defaultProps = {
  children: (
    <svg
      css={`
        width: 18.75rem;
        height: 4.5rem;
      `}>
      <use xlinkHref="#logo" />
    </svg>
  ),
}

export const NavMenu = styled.ul`
  display: flex;
  gap: 2.5rem;
  align-items: center;
  list-style: none;
  text-align: center;
  margin: 0 0 0 auto;
  padding: 0;
  height: 100%;
`

export const NavItem = styled.li`
  display: flex;
  height: 100%;
  align-items: center;
`

export const NavLinks = styled(Link)`
  color: #fff;
  display: flex;
  align-items: center;
  text-decoration: none;
  padding: 0.5rem 1rem;
  height: 100%;
`

export const NavBtnLink = styled(Link)`
  display: flex;
  justify-content: center;
  align-items: center;
  text-decoration: none;
  padding: 8px 16px;
  height: 100%;
  width: 100%;
  border: none;
  outline: none;
`

export const NavButton = styled(Button)`
  height: 4rem;
  min-width: 8rem;
  font-size: 1.5rem;
`
NavButton.defaultProps = {
  primary: true,
}
