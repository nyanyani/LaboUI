import styled from "styled-components"
import { Nav, NavLogo, NavMenu, NavItem, NavButton } from "./Navbar.elements"

function Navbar(props) {
  return (
    <Nav>
      <NavLogo to="/" alt="杭州世诺科技有限公司" />
      <NavMenu>
        <NavItem>
          <span>2021/06/04 (ver0.01)</span>
        </NavItem>
        <NavItem>
          <NavButton>关于我们</NavButton>
        </NavItem>
      </NavMenu>
    </Nav>
  )
}

export default Navbar
