import { format, parseISO } from "date-fns"
import zhCN from "date-fns/locale/zh-CN"

import React, {
  forwardRef,
  memo,
  useCallback,
  useContext,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from "react"
import { PrintResultCtx, PrintSelectCtx } from "@/states"
import { useCheckboxGroupItem } from "react-aria"

import { ToolTips } from "@/globalStyles"
import {
  CardCount,
  CardHeading,
  CardIcon,
  CardBarcode,
  CardWrapper,
  CardType,
  CardItem,
  CardStatusIcon,
  cardBorderFactor,
  CheckBoxLabel,
} from "./Card.elements"

const colors = new Map([
  ["red", "红"],
  ["blue", "蓝"],
  ["green", "绿"],
  ["yellow", "黄"],
  ["purple", "紫"],
  ["black", "黑"],
])
const size = new Map([
  ["short", "短管"],
  ["long", "长管"],
])

function Card(props) {
  const { item } = props
  const { index, barcode, heading, type, icon, detail, order } = item ?? {}

  const time = useMemo(() => parseISO(detail?.time), [detail])
  const printType = type === "tube" ? `${colors.get(icon.color)}${size.get(icon.size)}` : "副打印机"
  const tip = `项目：${heading}，类型：${printType} `

  return (
    <CardWrapper
      css={`
        ${order ? `order: ${order};` : undefined}
      `}>
      <CardCount>{index}</CardCount>
      <CardHeading data-desc="描述">{heading}</CardHeading>
      <CardType
        css={`
          color: var(--base-color-${icon.color});
        `}>
        {printType}
      </CardType>
      {type === "tube" ? (
        <CardIcon
          css={`
            color: var(--base-color-${icon.color});
            grid-column-end: tube-${icon.size};
          `}>
          <use xlinkHref={`#${type}-${icon.size}`} />
        </CardIcon>
      ) : (
        <CardIcon
          css={`
            grid-column-end: 3;
          `}>
          <use xlinkHref="#barcode" />
        </CardIcon>
      )}
      <span aria-label="detail-label">取单时间:</span>
      <span aria-label="detail-date">{format(time, "yyyy-MM-dd(eeee)", { locale: zhCN })}</span>
      <span aria-label="detail-time">{format(time, "bb hh:mm", { locale: zhCN })}</span>
      <span aria-label="detail-place">{detail?.place}</span>
      <CardBarcode>{barcode}</CardBarcode>
      <CardStatus barcode={barcode} type={type} tip={tip} />
    </CardWrapper>
  )
}

const resultStatusMap = ["succeed", "failed", "printing"]
const getStatus = (currResult, barcode) => {
  let currStatus = "pending"
  for (let i = 0; i < resultStatusMap.length; i++) {
    const key = resultStatusMap[i]
    if (currResult[key]?.includes(barcode)) {
      currStatus = key
      break
    }
  }
  return currStatus
}
const CardStatus = memo(({ barcode, type, tip }) => {
  const { printResult } = useContext(PrintResultCtx)

  const [status, setStatus] = useState("init")
  const [isSelected, setIsSelected] = useState(false)
  const [isDisabled, setIsDisabled] = useState(false)

  const checkRef = useRef()
  const orderRef = useRef(0)
  const lastStatus = useRef("init")

  let title = "点击选择打印项目"
  if (isDisabled && isSelected) {
    title = status === "pending" ? "该项目已安排打印, 请稍候" : `该项目打印${status === "succeed" ? "成功" : "失败"}`
  }
  if (isDisabled && !isSelected) {
    title = "点击底部“重打”按钮，进行重新选择"
  }
  if (!isDisabled && isSelected) {
    title = "点击取消当前选择"
  }
  if (!isDisabled && !isSelected) {
    title = `在上一次打印中，该项目打印${lastStatus.current === "succeed" ? "成功" : "失败"}`
  }

  const setStyle = useCallback((order) => {
    const card = checkRef.current.closest("li")
    if (order) {
      orderRef.current = order
      card.style.order = order
    }
    card.style.animation = "blink 0.6s ease-out"
  }, [])

  useEffect(() => {
    const li = checkRef.current.closest("li")
    const animationEnd = () => {
      const order = li.style.order || orderRef.current
      li.removeAttribute("style")
      if (order) {
        li.style.order = order
      }
      orderRef.current = 0
    }
    li.addEventListener("animationend", animationEnd)

    return () => {
      li.removeEventListener("animationend", animationEnd)
      li.removeAttribute("style")
    }
  }, [])

  useEffect(() => {
    if (isDisabled) {
      const currResult = printResult[type]
      const currStatus = getStatus(currResult, barcode)
      const order = currStatus === "printing" && -printResult.index
      setStatus((prevStatus) => {
        lastStatus.current = prevStatus
        if (prevStatus !== currStatus) {
          setStyle(order)
        }
        return currStatus
      })
    } else {
      setStatus("init")
    }
  }, [barcode, isDisabled, printResult, setStyle, type])

  return (
    <>
      <CheckBox
        value={barcode}
        aria-label="print-select"
        onChange={setIsSelected}
        onDisabled={setIsDisabled}
        ref={checkRef}
      />
      <CardStatusIcon
        css={status === "failed" ? "" : `color: ${isSelected || status === "succeed" ? "#32A151" : "#E0E0E0"};`}>
        <use xlinkHref={status === "failed" ? "#card-error" : "#card-select"} />
      </CardStatusIcon>
      <Label barcode={barcode} title={title} status={status} isDisabled={isDisabled} tip={tip} />
    </>
  )
})
CardStatus.displayName = "CardStatus"

const CheckBox = memo(
  forwardRef((props, checkRef) => {
    const { value } = props
    const { state, isDisabled } = useContext(PrintSelectCtx)
    const { inputProps } = useCheckboxGroupItem(props, state, checkRef)
    const { onChange, onDisabled } = props

    useLayoutEffect(() => {
      onChange(state.isSelected(value))
      onDisabled(isDisabled)
    }, [isDisabled, onChange, onDisabled, state, value])

    return <input type="checkbox" id={value} {...inputProps} ref={checkRef} />
  })
)
CheckBox.displayName = "CheckBox"

const Label = memo(({ barcode, title, status, isDisabled, tip }) => {
  const labelRef = useRef()

  useEffect(() => {
    const label = labelRef.current
    const card = label.closest("li")
    card?.prepend(label)
  }, [])

  return (
    <CheckBoxLabel
      htmlFor={barcode}
      title={title}
      status={status}
      data-tip={tip}
      css={`
        cursor: ${isDisabled ? "not-allowed" : "pointer"};
        ${cardBorderFactor}
        ${ToolTips}
      `}
      ref={labelRef}>
      <span css={status === "init" || status === "pending" ? undefined : "background: #fff;"} />
    </CheckBoxLabel>
  )
})
Label.displayName = "Label"

export default memo(Card)
