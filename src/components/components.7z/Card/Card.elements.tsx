import { ToolTips } from "@/globalStyles"
import flexUnit from "@/utils/flexUnit"
import styled, { css } from "styled-components"
import { collapseOneRow } from "../PrintList/PrintList.elements"

export const CardItem = styled.div``
export const CardDescription = styled.p``

const wrapperMediaQuery = ({ cols, rows }) => {
  const twoRows = (offset) => `
    & {
      grid-template-areas:
        "count heading . . type status"
        "icon icon icon . detail-label detail-label"
        "icon icon icon . detail-date detail-date"
        "icon icon icon . detail-time detail-time"
        "barcode barcode barcode barcode detail-place detail-place";
    }
  `
  return `
  ${collapseOneRow()}
`
}

export const CardWrapper = styled.div`
  position: relative;
  width: 100%;
  height: 100%;
  overflow: visible;
  font-size: 0;
  vertical-align: middle;
  pointer-events: none;

  display: grid;
  grid-template-columns: minmax(5rem, 4fr) 10fr [tube-short] 3fr [tube-long] 1fr 10fr 4rem;
  grid-template-rows: 4rem repeat(4, 1fr);
  grid-auto-columns: 1fr;
  grid-auto-rows: 1fr;
  grid-template-areas:
    "count heading . . type status"
    "icon icon icon . detail-label detail-label"
    "icon icon icon . detail-date detail-date"
    "icon icon icon . detail-time detail-time"
    "barcode barcode barcode barcode detail-place detail-place";
  align-items: center;

  [aria-label^="detail"] {
    display: inline-block;
    font-size: calc((var(--base-rows) / var(--content-rows)) * 1.75rem);
    ${flexUnit(null, "16px", "20px", "0px", "500px", "font-size", "vh")}
  }
  [aria-label$="label"] {
    grid-area: detail-label;
  }
  [aria-label$="date"] {
    grid-area: detail-date;
  }
  [aria-label$="time"] {
    grid-area: detail-time;
  }
  [aria-label$="place"] {
    grid-area: detail-place;
  }

  & > span {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  input[type="checkbox"] {
    visibility: hidden;
    &:checked {
      counter-increment: select-count 1;
    }
  }
`

export const CardCount = styled.span`
  grid-area: count;
  letter-spacing: -0.25rem;
  line-height: 4rem;
  font-weight: bold;

  ${flexUnit("4rem", "20px", "48px", "1000px")}
`

export const CardHeading = styled.span`
  grid-area: heading;
  display: inline-block;
  white-space: nowrap;
  line-height: 4rem;
  ${flexUnit("2.5rem", "16px", "30px", "1000px")}
`

export const CardType = styled.span`
  display: inline-block;
  grid-area: type;
  letter-spacing: -0.25rem;
  font-weight: 500;
  ${flexUnit("3rem", "20px", "36px", "1000px")}
`

export const CardIcon = styled.svg`
  grid-area: icon;
  width: 100%;
  height: 100%;
`

export const CardBarcode = styled.span`
  grid-area: barcode;
  ${flexUnit(
    "calc(var(--base-rows) / var(--content-rows, --base-rows) * 2.25rem)",
    "16px",
    "20px",
    "100vw",
    null,
    "font-size",
    "vw",
    "padding-left: 1.5rem;"
  )}
`

export const CardStatusIcon = styled.svg`
  grid-area: status;
  width: 4rem;
  height: 4rem;
`

export const resultBorder = (color, status) => `
  border: 0;
  ${
    status === "printing"
      ? `
    --border-color: hsl(var(--h, 0), var(--s, 100%), 40%);
    background: conic-gradient(from var(--a, 60deg), transparent, var(--border-color), transparent);
    animation: printing 1.5s infinite cubic-bezier(0.4, 0, 1, 1);
    `
      : `background: conic-gradient(from 60deg, transparent 10%, var(--base-color-${color}), transparent);`
  }
`

export const cardBorderFactor = css(({ status }) => {
  if (status === "init") {
    return `
      transition: 0.1s border-width linear;
      &:hover {
        border-width: 4px;
      }
    `
  }
  if (status === "pending") {
    return `
      z-index: 5;
      border: 0;
      background: #43434322;
    `
  }
  if (status === "printing") {
    return resultBorder("orange", "printing")
  }
  if (status === "succeed") {
    return resultBorder("green")
  }
  if (status === "failed") {
    return resultBorder("red")
  }
})

export const CheckBoxLabel = styled.label`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border: 2px solid;
  border-radius: 2rem;

  span {
    position: absolute;
    top: 6px;
    left: 6px;
    right: 6px;
    bottom: 6px;
    border-radius: calc(2rem - 6px);
  }
`
