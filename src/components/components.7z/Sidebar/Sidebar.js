import { CamStreamContainer } from "@/states"

import { Aside, MenuNav, MenuContainer } from "./Menu.elements"
import CamVideo from "./CamVideo"
import MenuItem from "./MenuItem"
import PatientInfo from "./PatientInfo"
import QueueHistory from "./QueueHistory"

function Sidebar() {
  return (
    <Aside>
      <MenuNav>
        <MenuContainer>
          <MenuItem menuType="info" description="患者信息" icon="info">
            <PatientInfo />
          </MenuItem>
          <MenuItem menuType="cam" description="采集图像" icon="cam">
            <CamStreamContainer>
              <CamVideo />
            </CamStreamContainer>
          </MenuItem>
          <MenuItem menuType="list" description="历史记录" icon="history">
            <QueueHistory />
          </MenuItem>
        </MenuContainer>
      </MenuNav>
    </Aside>
  )
}

export default Sidebar
