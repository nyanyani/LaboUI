/* eslint-disable react/display-name */
import { Center, Loading } from "@/globalStyles"
import { PageInfoCtx, PatientInfoCtx, QueueInfoCtx } from "@/states"
import React, { memo, useContext, useMemo } from "react"
import { PatientGrid, GridItem } from "./Menu.elements"

const IdleCard = memo((props) => {
  const { calling } = useContext(QueueInfoCtx)
  const { queueNum } = calling ?? {}

  return (
    <Center>
      {queueNum ? (
        <>
          <span>正在等待第</span>
          <span
            css={`
              display: inline-block;
              color: var(--base-color-green);
              font-weight: bold;
              min-width: 5rem;
              text-align: center;
            `}>
            {queueNum}
          </span>
          <span>号</span>
        </>
      ) : (
        <span>当前未叫号</span>
      )}
    </Center>
  )
})

const PatientCard = memo((props) => {
  const { patient } = useContext(PatientInfoCtx)
  const { name, age, gender, queueNum, item, id } = patient

  return patient.queueNum ? (
    <PatientGrid>
      <GridItem aria-label="name">{name}</GridItem>
      <GridItem aria-label="gender">{gender === "m" ? "男" : "女"}</GridItem>
      <GridItem aria-label="age">{age} 岁</GridItem>
      <GridItem aria-label="number" data-number={queueNum}>
        号
      </GridItem>
      <GridItem aria-label="item">{item}</GridItem>
      <GridItem aria-label="id">{id}</GridItem>
    </PatientGrid>
  ) : (
    <Loading>等待患者数据</Loading>
  )
})

function PatientInfo(props) {
  const { pageStatus } = useContext(PageInfoCtx)

  switch (pageStatus) {
    case "idle":
    case "calling":
      return <IdleCard />
    default:
      return <PatientCard />
  }
}

export default PatientInfo
