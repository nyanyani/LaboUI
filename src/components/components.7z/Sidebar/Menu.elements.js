import { Button, Ul } from "@/globalStyles"
import styled, { css } from "styled-components"

export const Aside = styled.aside`
  width: 45rem;
  display: flex;
  height: 100%;
  flex-direction: column;
  border-radius: 3rem;
  overflow-y: scroll;

  @media screen and (max-width: 600px) {
    width: 100%;
    flex-basis: 30rem;
    flex-shrink: 0;
  }

  &:hover::-webkit-scrollbar-thumb {
    background-color: #bdbdbd;
  }
`

export const MenuContainer = styled.ul`
  display: flex;
  margin: 0;
  padding: 0;
  list-style: none;
  flex-direction: column;
  gap: 2rem;

  @media screen and (max-width: 600px) {
    flex-direction: row;
    justify-content: space-between;
    li {
      flex: 1;
    }
  }
`

export const MenuNav = styled.nav`
  width: 100%;
  height: 100%;
`

export const MenuButton = styled(Button)`
  width: 9rem;
  height: 4rem;
`
MenuButton.defaultProps = {
  primary: true,
}

export const SubMenu = styled(MenuContainer)``

export const Item = styled.li`
  & > * {
    transition: all 0.2s linear;
  }
`

export const ItemHeading = styled.div`
  display: flex;
  align-items: center;
  height: 5rem;
  padding: 1rem;
  gap: 2rem;
  cursor: pointer;
  font-size: 2.5rem;
`

export const ItemIcon = styled.svg`
  width: 3rem;
  height: 3rem;

  transition: all 0.2s linear -0.1s;
`

export const ItemDescription = styled.span`
  display: inline-block;
  margin-right: auto;
`

export const ItemContent = styled.div`
  position: relative;
  width: 100%;
  min-height: 11rem;
  max-height: 100vh;
  padding: 1rem;
  background: #fff;
  border-radius: 0 0 3rem 3rem;
`

export const Video = styled.video`
  width: 100%;
  cursor: pointer;
`

export const PatientGrid = styled.div`
  display: grid;
  position: relative;
  font-size: 2.5rem;
  align-items: center;
  row-gap: 1.5rem;
  grid-template-columns: 2fr repeat(3, 1fr);
  grid-template-rows: 1fr 1fr;
  grid-template-areas: "name  gender age number number" "item id id id id";

  [aria-label$="name"] {
    grid-area: name;
  }
  [aria-label$="gender"] {
    grid-area: gender;
  }
  [aria-label$="age"] {
    grid-area: age;
  }
  [aria-label$="number"] {
    grid-area: number;
    position: relative;
    justify-self: end;
    overflow: visible;

    &::before {
      position: absolute;
      top: calc(50% - 2px);
      right: calc(100% + 0.25rem);
      transform: translateY(-50%);
      content: attr(data-number);
      color: var(--base-color-green);
      font-weight: 500;
      font-size: 3.5rem;
      letter-spacing: -0.25rem;
    }
  }
  [aria-label$="item"] {
    grid-area: item;
  }
  [aria-label$="id"] {
    grid-area: id;
    justify-self: end;
  }
`

export const GridItem = styled.span`
  display: inline-block;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
`

export const HistoryWrapper = styled(Ul)`
  display: flex;
  flex-direction: column;
  font-size: 2rem;

  li:last-of-type {
    border: 0;
  }
`
export const HistoryGrid = styled.li`
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 1fr;
  grid-template-areas: "number name time status";
  padding: 0.5rem 1rem;
  border-bottom: 0.1rem solid #cacaca;
  cursor: pointer;
`

export const CamWrapper = styled.div`
  position: relative;
  border: 0.25rem solid;
  border-radius: 2rem;
  overflow: hidden;
  width: 40rem;
  height: 22.5rem;
  margin: auto;

  &:hover {
    #cam-controller {
      opacity: 1;
      visibility: visible;
    }
  }
`

export const ControllerWrapper = styled.div`
  position: absolute;
  left: 0;
  bottom: 0;
  display: flex;
  gap: 4rem;
  justify-content: space-between;
  width: 100%;
  background: rgba(50, 50, 50, 0.5);
  border-radius: 0 0 2rem 2rem;
  padding: 1rem;
  font-size: 2rem;
  transition: 0.5s opacity linear;
  opacity: 0;
  visibility: hidden;

  button {
    height: 4rem;
    width: 10rem;
  }
`
export const CamLoadingWrapper = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: #e0e0e0;
`
export const CamLoadingSVG = styled.svg`
  width: 100%;
  height: 100%;
  cursor: pointer;
`
CamLoadingSVG.defaultProps = {
  title: "请开启相机",
  children: <use xlinkHref="#camLoading" />,
}
