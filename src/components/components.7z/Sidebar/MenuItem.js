import { PageInfoCtx } from "@/states"
import { useCallback, useContext, useState, useLayoutEffect, memo } from "react"

import { Item, ItemIcon, ItemDescription, ItemHeading, ItemContent } from "./Menu.elements"

function MenuItem({ initFold = true, icon, description, children, menuType, ...restProps }) {
  const { pageStatus } = useContext(PageInfoCtx)
  const [fold, setFold] = useState(initFold && pageStatus === "idle")

  useLayoutEffect(() => {
    if (pageStatus !== "idle") {
      setFold(false)
    }
  }, [pageStatus])

  const handleClick = useCallback(() => {
    setFold(!fold)
  }, [fold])

  return (
    <Item>
      <ItemHeading
        css={`
          ${!fold && "background: var(--base-color); color: #fff; border-radius: 2rem 2rem 0 0;"};
        `}
        onClick={handleClick}>
        <ItemIcon>
          <use xlinkHref={`#${icon}`} />
        </ItemIcon>
        <ItemDescription>{description ?? "Description"}</ItemDescription>
        <ItemIcon
          css={`
            width: 2rem;
            height: 2rem;
            ${!fold && `transform: rotate(-90deg);`}
          `}>
          <use xlinkHref="#arrow" />
        </ItemIcon>
      </ItemHeading>
      <ItemContent
        css={`
          ${fold &&
          `overflow: hidden;
          max-height: 0;
          min-height: 0;
          padding: 0;
          `}
        `}>
        {children}
      </ItemContent>
    </Item>
  )
}

export default memo(MenuItem)
