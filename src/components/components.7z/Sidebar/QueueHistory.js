import { Center, Ul } from "@/globalStyles"
import { QueueHistoryCtx } from "@/states"
import { useCallback, useContext, useMemo } from "react"
import { GridItem } from "../Layout/Layout.elements"
import { HistoryGrid, HistoryWrapper } from "./Menu.elements"

function QueueHistory(props) {
  const { queueHistory } = useContext(QueueHistoryCtx)

  return queueHistory?.length ? (
    <HistoryWrapper>
      {queueHistory.map(({ name, id, number, time, skipped }) => (
        <HistoryGrid key={id}>
          <GridItem $area="number">{number}号</GridItem>
          <GridItem $area="name">{name}</GridItem>
          <GridItem $area="time">{time}</GridItem>
          <GridItem
            css={`
              grid-area: status;
              color: var(--base-color-${skipped ? "orange" : "green"});
              justify-self: end;
            `}>
            {skipped ? "已过号" : "已采集"}
          </GridItem>
        </HistoryGrid>
      ))}
    </HistoryWrapper>
  ) : (
    <Center>暂时未有采集数据</Center>
  )
}

export default QueueHistory
