import { memo, useCallback, useContext, useEffect, useMemo, useRef } from "react"

import { CamPicContainer, CamPicCtx, CamStreamCtx, PageInfoCtx, PatientInfoCtx } from "@/states"
import { Button, Loading } from "../../globalStyles"
import { CamLoadingSVG, CamLoadingWrapper, CamWrapper, ControllerWrapper, Video } from "./Menu.elements.js"
import Dialog, { ButtonTrigger, Controller, DialogTrigger } from "../Dialog/Dialog"

const Cam = memo((props) => {
  const { videoRef } = useContext(CamStreamCtx)
  const { dataUrl, handleFilm } = useContext(CamPicCtx)
  const { patientInfo, setCurrPatient } = useContext(PatientInfoCtx)
  const { pageStatus } = useContext(PageInfoCtx)

  useEffect(() => {
    const video = videoRef.current
    if (pageStatus !== "pending" || !video) {
      return
    }

    const setCurrFilm = () => {
      handleFilm(video)
      setCurrPatient(() => ({ ...patientInfo, image: dataUrl }))
    }
    video.addEventListener("click", setCurrFilm)

    return () => {
      video.removeEventListener("click", setCurrFilm)
    }
  }, [handleFilm, videoRef, pageStatus, setCurrPatient, patientInfo, dataUrl])

  return <Video ref={videoRef} />
})
Cam.displayName = "Cam"

const SwitchButton = memo(() => {
  const { cameraDevices, handleSwitch } = useContext(CamStreamCtx)
  const formRef = useRef()

  return (
    <DialogTrigger label="切换相机" title="切换相机" primary $main="orange">
      <Dialog>
        {cameraDevices.default ? (
          <>
            <div>
              {Object.entries(cameraDevices).map(
                ([key, id]) =>
                  key !== "default" && (
                    <div
                      key={`${key}${id}`}
                      css={`
                        display: flex;
                        gap: 2rem;
                      `}>
                      <span
                        css={`
                          display: inline-block;
                          overflow: hidden;
                          min-width: 10rem;
                        `}>
                        {key}
                        {id === cameraDevices.default && "(当前选择)"}
                      </span>
                      <span
                        css={`
                          display: inline-block;
                          width: 20rem;
                          text-overflow: ellipsis;
                          overflow: hidden;
                        `}>
                        {id}
                      </span>
                    </div>
                  )
              )}
            </div>
            <form ref={formRef}>
              <div
                css={`
                  display: flex;
                  justify-content: space-between;
                `}>
                <label htmlFor="videoInput">选择相机</label>
                <select
                  id="videoInput"
                  defaultValue={cameraDevices.default}
                  css={`
                    width: 15rem;
                  `}>
                  {Object.entries(cameraDevices).map(
                    ([key, id]) =>
                      key !== "default" && (
                        <option key={`${key}${id}`} value={id}>
                          {key}
                        </option>
                      )
                  )}
                </select>
              </div>
            </form>
          </>
        ) : (
          <span
            css={`
              width: 100%:
              text-align: center;
            `}>
            未检测到相机
          </span>
        )}
        <Controller onConfirm={() => formRef.current && handleSwitch(formRef.current[0].value)} />
      </Dialog>
    </DialogTrigger>
  )
})
SwitchButton.displayName = "SwitchButton"

const StartButton = memo(() => {
  const { mediaStream, loading, shot, handleStream, handleFilm } = useContext(CamStreamCtx)

  return (
    <Button disabled={loading} primary={!mediaStream} onClick={handleStream}>
      {mediaStream ? "关闭相机" : "开启相机"}
    </Button>
  )
})
StartButton.displayName = "StartButton"

const CaptureButton = memo(() => {
  const { mediaStream, stopStreaming, shot, handleFilm } = useContext(CamStreamCtx)
  const { pageStatus } = useContext(PageInfoCtx)
  const loading = !stopStreaming && !mediaStream

  return (
    <Button
      $main={mediaStream && pageStatus === "pending" ? "green" : "red"}
      primary
      onClick={handleFilm}
      disabled={!mediaStream || loading || pageStatus !== "pending"}>
      {shot && mediaStream ? "重拍" : "核对"}
    </Button>
  )
})
CaptureButton.displayName = "CaptureButton"

const CamLoading = memo(() => {
  const { stopStreaming, mediaStream } = useContext(CamStreamCtx)
  const loading = !stopStreaming && !mediaStream

  if (mediaStream) {
    return null
  }

  return (
    <CamLoadingWrapper>
      {loading ? <Loading>正在打开相机</Loading> : !mediaStream && <CamLoadingSVG />}
    </CamLoadingWrapper>
  )
})

CamLoading.displayName = "CamLoading"

function CamVideo(props) {
  return (
    <CamWrapper>
      <CamPicContainer>
        <Cam />
      </CamPicContainer>
      <CamLoading />
      <ControllerWrapper id="cam-controller">
        <CaptureButton />
        <StartButton />
        <SwitchButton />
      </ControllerWrapper>
    </CamWrapper>
  )
}

export default CamVideo
