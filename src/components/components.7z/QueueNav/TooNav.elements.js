import styled from "styled-components"

export const WidgetWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  width: 13rem;
  height: 9rem;
  font-size: 0;
  line-height: 9rem;
  white-space: nowrap;
`
export const WidgetLabel = styled.span`
  display: inline-block;
  vertical-align: middle;
`

export const WidgetTitle = styled(WidgetLabel)`
  text-align: left;
  font-size: 2rem;
`

export const WidgetDetail = styled(WidgetLabel)`
  font-size: 3rem;
  font-weight: bold;
  text-align: right;
  letter-spacing: -0.25rem;
  transform: skewX(-10deg);
`
