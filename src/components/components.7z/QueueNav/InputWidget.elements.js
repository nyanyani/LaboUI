import { BaseButton, Icon } from "@/globalStyles"
import styled from "styled-components"

export const FormWrapper = styled.form`
  position: relative;
  display: flex;
  flex: 1;
  padding: 0 1rem;
  justify-content: space-between;
  align-items: center;
  height: 4rem;
`

export const BaseInput = styled.input`
  border: 0;
  height: 100%;
  flex: 1;
  color: currentColor;

  &:focus {
    outline: none;
  }
  &:disabled {
    user-select: none;
    cursor: not-allowed;
  }
`

export const InputMask = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border: 0.3rem solid currentColor;
  border-radius: 0.5rem;
  pointer-events: none;
`

export const SubmitButton = styled(BaseButton)`
  width: 3rem;
  height: 3rem;
  color: currentColor;
`
SubmitButton.defaultProps = {
  type: "submit",
  children: (
    <Icon>
      <use xlinkHref="#inputScan" />
    </Icon>
  ),
}
