import React, { forwardRef, memo, useCallback, useContext, useEffect, useLayoutEffect, useRef, useState } from "react"
import { OverlayContainer, useButton, useFocus, useTextField } from "react-aria"

import { ErrorCtx, PageInfoCtx, PatientInfoCtx, PrintListCtx, QueueInfoCtx, SettingCtx } from "@/states"
import { getPatientInfo, getPrintInfo } from "@/apis"
import { queryQueue, updateQueue } from "@/apis/handleQueue"
import { isValidInput } from "@/utils"

import { Button, Loading } from "@/globalStyles"
import Dialog from "../Dialog/Dialog"
import { ControllerWrapper } from "../Dialog/Dialog.elements"
import { FormWrapper, BaseInput, InputMask, SubmitButton } from "./InputWidget.elements"

const QueueDialog = memo((props) => {
  const { onConfirm: confirm, onCancel: cancel, error, code } = props
  const [isOpen, setOpen] = useState(false)

  useEffect(() => {
    setOpen(!!code)
  }, [code])

  const cancelRef = useRef()
  const confirmRef = useRef()

  const { buttonProps: confirmProps } = useButton(
    {
      onPress: () => {
        setOpen(false)
        if (typeof confirm === "function") {
          confirm()
        }
      },
      isDisabled: code === 1,
    },
    confirmRef
  )
  const { buttonProps: cancelProps } = useButton(
    {
      onPress: () => {
        setOpen(false)
        if (typeof cancel === "function") {
          cancel()
        }
      },
      isDisabled: code === 1,
    },
    confirmRef
  )

  const closeDialog = useCallback(() => setOpen(false), [])

  return (
    isOpen && (
      <OverlayContainer>
        <Dialog isOpen={isOpen} title="患者信息" onClose={closeDialog}>
          {code === 1 ? <Loading>正在获取信息</Loading> : <div>{error}</div>}
          <ControllerWrapper>
            <Button primary $width="10rem" {...cancelProps} ref={cancelRef}>
              取消
            </Button>
            {(code === 2 || code === 4) && (
              <Button $width="10rem" {...confirmProps} ref={confirmRef}>
                继续
              </Button>
            )}
          </ControllerWrapper>
        </Dialog>
      </OverlayContainer>
    )
  )
})
QueueDialog.displayName = "QueueDialog"

const Input = memo(
  forwardRef((props, ref) => {
    const [inputValue, setInputValue] = useState("")

    const { inputProps } = useTextField(
      {
        "aria-label": "queue-id",
        placeholder: "扫描或输入卡号",
        autoFocus: true,
        autoComplete: "off",
        value: inputValue,
        onInput: (e) => {
          const { value } = e.target
          if (isValidInput(value)) {
            setInputValue(value.trim())
          }
        },
        ...props,
      },
      ref
    )
    return <BaseInput {...inputProps} ref={ref} />
  })
)
Input.displayName = "Input"

function InputWidget(props) {
  const { pageStatus, setCurrStatus } = useContext(PageInfoCtx)

  const [isBlur, setBlur] = useState(pageStatus === "calling")

  const { setCurrPrintList } = useContext(PrintListCtx)
  const { setCurrPatient } = useContext(PatientInfoCtx)
  const { calling, setCurrCalling } = useContext(QueueInfoCtx)

  const [queryInfo, setQueryInfo] = useState(null)

  // 0: init, 1: loading, 2: first step confirm, 3: second step confirm, 4: continue, 5: error
  const [code, setCode] = useState(0)

  const [inputError, setInputError] = useState(null)

  const inputRef = useRef()

  const continueQuery = useCallback(async () => {
    const { patientId, queueNum } = queryInfo ?? calling
    setCode(1)
    if (calling.queueNum && code === 4) {
      updateQueue({ queueNum: calling.queueNum, status: { skipped: true } })
    }
    const payload = await Promise.allSettled([getPatientInfo(patientId), getPrintInfo(patientId)]).catch(console.log)
    setCode(0)
    const [patientInfo, printList] = payload.map((item) => item.value)
    if (patientInfo) {
      setCurrPatient({ ...patientInfo, queueNum })
      setCurrCalling({ queueNum, patientId, repeat: 0 })
    }
    if (printList) {
      setCurrPrintList(printList)
    }
    setQueryInfo(null)
    if (!patientInfo && !printList) {
      setInputError("未找到数据。")
      setCode(5)
    } else {
      setCurrStatus("pending")
    }
  }, [queryInfo, calling, code, setCurrPatient, setCurrCalling, setCurrPrintList, setCurrStatus])

  const handleFocus = useCallback((isFocused) => {
    const input = inputRef.current
    if (!input) {
      return
    }
    setTimeout(() => {
      input.selectionStart = 0
      input.selectionEnd = -1

      if (!isFocused) {
        window.getSelection().empty()
      }
    })
    setBlur(!isFocused)
  }, [])
  const handleSubmit = useCallback(
    async (e) => {
      e.preventDefault()
      const inputValue = inputRef.current.value
      if (inputValue === "") {
        return
      }
      if (inputValue !== calling.patientId) {
        setInputError("该患者非当前叫号， 是否继续？")
        setQueryInfo({ patientId: inputValue })
        setCode(2)
        return
      }
      continueQuery()
      setQueryInfo(calling)
      setBlur(true)
    },
    [calling, continueQuery]
  )
  const handleConfirm = useCallback(() => setCode(3), [])
  const handleCancel = useCallback(() => setCode(0), [])

  const isDisabled = pageStatus !== "calling" && pageStatus !== "idle"
  useLayoutEffect(() => {
    const inputValue = inputRef.current.value
    if (code === 0) {
      setQueryInfo(null)
      setInputError(null)
    }
    // code2 handled by dialog
    if (code === 3) {
      ;(async () => {
        setCode(1)
        const queue = await queryQueue(inputValue)
        if (!queue || !queue.length) {
          setInputError("该患者未取号。")
          setCode(5)
          return
        }
        const latest = queue.reduce((result, item) => (result.queueNum > item.queueNum ? result : item), {
          queueNum: 0,
        })
        const { queueNum, patientId, windowNum: prevWindow, skipped, executed, pending } = latest
        const msgIdx = (skipped && 1) + (executed && 2) + (pending && 3) - 1
        const msg = [
          "该患者已过号，请重新取号。",
          `该患者已在${prevWindow}号窗口采集。`,
          `该患者正在${prevWindow}号窗口采集。`,
        ]
        setQueryInfo({ patientId, queueNum })
        setInputError(msg[msgIdx] ?? null)
        setCode(msgIdx === 0 ? 5 : 4)
      })()
    }
    if (code === 4) {
      setQueryInfo(calling)
      continueQuery()
    }
  }, [calling, code, continueQuery])

  useEffect(() => {
    const input = inputRef.current
    setTimeout(() => {
      input.value = calling.patientId || ""
      input.focus()
    })
  }, [calling])

  return (
    <FormWrapper onSubmit={handleSubmit}>
      <InputMask css={isBlur || isDisabled ? "opacity: 0.4;background: #fff;" : ""} />
      <Input onFocusChange={handleFocus} isDisabled={isDisabled} ref={inputRef} />
      <SubmitButton disabled={isDisabled} />
      <QueueDialog code={code} error={inputError} onConfirm={handleConfirm} onCancel={handleCancel} />
    </FormWrapper>
  )
}

export default memo(InputWidget)
