import React, { memo, useCallback, useEffect, useMemo, useState } from "react"
import zhCN from "date-fns/locale/zh-CN"
import { differenceInMilliseconds, endOfMinute, format } from "date-fns"

const formatDay = (dateObj) => format(dateObj, "MM/dd (eeee)", { locale: zhCN })
const formatTime = (dateObj) => format(dateObj, "bb hh:mm", { locale: zhCN })

const nextMinute = (nextTime, callback) => {
  const delay = differenceInMilliseconds(endOfMinute(nextTime), nextTime)

  setTimeout(() => nextMinute(delay, callback), delay)
  callback()
}

const initDate = Date.now()
function TimeWidget() {
  const [currentTime, setCurrentTime] = useState(initDate)

  useEffect(() => {
    nextMinute(initDate, () => setCurrentTime(() => Date.now()))
  }, [])

  return (
    <div
      css={`
        width: 14rem;
        span {
          display: inline-block;
        }
      `}>
      <span>{formatDay(currentTime)}</span>
      <span>{formatTime(currentTime)}</span>
    </div>
  )
}

export default memo(TimeWidget)
