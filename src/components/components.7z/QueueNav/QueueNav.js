/* eslint-disable react/display-name */
import React, { memo, useCallback, useContext, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react"

import { ErrorCtx, PageInfoCtx, PatientInfoCtx, PrintListCtx, QueueInfoCtx, SettingCtx } from "@/states"
import { getHead, updateQueue } from "@/apis"
import { useHistory } from "react-router-dom"
import { useButton } from "react-aria"
import { initValues } from "@/utils/getCache"
import { exitFullscreen } from "@/utils"
import { addEvent, removeEvent, sendMessage } from "@/apis/handleQueue"
import { Loading } from "@/globalStyles"
import { Nav, NavItem, NavLogo, NavMenu } from "../Navbar/Navbar.elements"
import TimeWidget from "./TimeWidget"
import InputWidget from "./InputWidget"
import { MenuButton } from "../Sidebar/Menu.elements"
import Dialog, { Controller, DialogTrigger } from "../Dialog/Dialog"
import { WidgetDetail, WidgetTitle, WidgetWrapper } from "./TooNav.elements"

const Waiting = memo(() => {
  const { waiting } = useContext(QueueInfoCtx)

  return (
    <WidgetWrapper>
      {waiting ? (
        <>
          <WidgetTitle>排队人数</WidgetTitle>
          <WidgetDetail
            css={`
              color: var(--base-color-orange);
            `}>
            {waiting}
          </WidgetDetail>
        </>
      ) : (
        <WidgetTitle
          css={`
            width: 100%;
          `}>
          当前无排队
        </WidgetTitle>
      )}
    </WidgetWrapper>
  )
})

const Calling = memo(() => {
  const { pageStatus } = useContext(PageInfoCtx)
  const { calling } = useContext(QueueInfoCtx)
  const { queueNum } = calling

  return (
    <WidgetWrapper>
      {queueNum && pageStatus !== "idle" ? (
        <>
          <WidgetTitle>当前叫号</WidgetTitle>
          <WidgetDetail
            css={`
              color: var(--base-color-green);
            `}>
            {queueNum}
          </WidgetDetail>
        </>
      ) : (
        <WidgetTitle
          css={`
            width: 100%;
          `}>
          当前未叫号
        </WidgetTitle>
      )}
    </WidgetWrapper>
  )
})

const NextButton = memo(() => {
  const { pageStatus, setCurrStatus } = useContext(PageInfoCtx)
  const { setCurrPrintList } = useContext(PrintListCtx)
  const { setCurrPatient } = useContext(PatientInfoCtx)
  const { head, waiting, calling, setCurrCalling } = useContext(QueueInfoCtx)

  const [isOpen, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)

  const { queueNum } = calling

  const isDisabled = pageStatus === "printing" || waiting === 0
  const shouldConfirm = queueNum && !(pageStatus === "calling" || pageStatus === "executed" || pageStatus === "pending")

  const handleNext = useCallback(async () => {
    if (shouldConfirm) {
      setOpen(true)
      return
    }
    if (!waiting) {
      setCurrStatus("idle")
      setCurrCalling()
      return
    }

    sendMessage("call-head")
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
    }, 2000)
  }, [setCurrCalling, setCurrStatus, shouldConfirm, waiting])

  const handleSkip = useCallback(
    (currQueueNum, nextStatus) => {
      updateQueue({
        queueNum: currQueueNum,
        status: { skipped: true },
      })
      setCurrStatus(nextStatus)
      setCurrPatient()
      setCurrPrintList()
      setLoading(true)
    },
    [setCurrStatus, setCurrPatient, setCurrPrintList]
  )

  const buttonRef = useRef()

  const { buttonProps } = useButton({
    onPress: () => {
      handleNext(queueNum, head ? "calling" : "idle")
    },
    isDisabled,
  })

  useLayoutEffect(() => {
    const updateCalling = (data) => {
      setCurrCalling({
        ...data,
        repeat: 0,
      })
      setLoading(false)
      setCurrStatus("calling")
    }
    addEvent("call-head", updateCalling)

    return () => {
      removeEvent("call-head", updateCalling)
    }
  }, [setCurrCalling, setCurrStatus])

  return (
    <>
      <MenuButton ref={buttonRef} {...buttonProps}>
        下一位
      </MenuButton>
      {isOpen && (
        <Dialog isOpen isDismissable title="提示" onClose={() => setOpen(false)}>
          <div>是否跳过当前第{queueNum}号?</div>
          <Controller onConfirm={handleSkip} cancelable />
        </Dialog>
      )}
      {loading && (
        <Dialog title="请稍等" onClose={() => setLoading(false)}>
          <Loading
            css={`
              font-size: 2.5rem;
            `}>
            获取叫号数据中
          </Loading>
        </Dialog>
      )}
    </>
  )
})

const RepeatButton = memo(() => {
  const { pageStatus } = useContext(PageInfoCtx)
  const { setCurrCalling } = useContext(QueueInfoCtx)

  const handleRepeat = useCallback(() => {
    sendMessage("repeat-call")
    setCurrCalling((prevCalling) => ({ ...prevCalling, repeat: prevCalling.repeat + 1 }))
  }, [setCurrCalling])

  const buttonRef = useRef()

  const { buttonProps } = useButton({
    onPress: () => handleRepeat(),
    isDisabled: pageStatus !== "calling",
    $width: "100%",
    $height: "100%",
  })

  return (
    <MenuButton ref={buttonRef} {...buttonProps}>
      重呼
    </MenuButton>
  )
})

const PauseButton = memo(() => {
  const { setCurrStatus } = useContext(PageInfoCtx)
  const { calling, setCurrCalling } = useContext(QueueInfoCtx)
  const { setCurrPatient } = useContext(PatientInfoCtx)

  const { queueNum } = calling ?? {}

  const [isOpen, setOpen] = useState(false)

  const history = useHistory()

  const handlePause = useCallback(() => {
    if (queueNum) {
      updateQueue({ queueNum, status: { skipped: true, stop: true } })
    }
    sendMessage("stop-call", { showInfo: "窗口暂停服务" })
    setCurrCalling()
    setCurrPatient()
    setCurrStatus("idle")
    exitFullscreen()
    history.push("/")
  }, [queueNum, setCurrCalling, setCurrPatient, setCurrStatus, history])

  const buttonRef = useRef()

  const { buttonProps } = useButton({
    onPress: () => setOpen(true),
  })

  return (
    <>
      <MenuButton $main="red" ref={buttonRef} {...buttonProps}>
        暂停
      </MenuButton>
      {isOpen && (
        <Dialog isOpen isDismissable title="提示" onClose={() => setOpen(false)}>
          <div>是否暂停?</div>
          <Controller onConfirm={handlePause} cancelable />
        </Dialog>
      )}
    </>
  )
})

function ToolNav() {
  return (
    <Nav
      css={`
        width: 100vw;
        gap: 3.5rem;
      `}>
      <NavLogo
        to="/"
        css={`
          font-size: 2.5rem;
        `}>
        C173宇宙救助站
      </NavLogo>
      <TimeWidget />
      <Waiting />
      <Calling />
      <InputWidget />

      <NavMenu
        css={`
          margin-left: auto;
          height: 100%;
        `}>
        <NavItem key="btn-print-all" id="print-all" />
        <NavItem key="btn-queue-next">
          <NextButton />
        </NavItem>
        <NavItem key="btn-queue-repeat">
          <RepeatButton />
        </NavItem>
        <NavItem key="btn-queue-pause">
          <PauseButton />
        </NavItem>
      </NavMenu>
    </Nav>
  )
}

export default memo(ToolNav)
