import { Arrow, Center, ToolTips } from "@/globalStyles"
import styled, { css } from "styled-components"
import { ErrorItem } from "../Error/Error.elements"

export { MenuButton } from "../Sidebar/Menu.elements"

export const Wrapper = styled.div`
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  width: 9rem;
  font-size: 2rem;
`

export { Nav, NavMenu, NavItem } from "../Navbar/Navbar.elements"

export const CountWrapper = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  width: 100%;
  height: 14rem;
  font-size: 6rem;
  margin-top: 5px;

  & > span {
    position: relative;
    display: inline-block;
    width: 100%;
    text-align: center;
    font-weight: bold;
    letter-spacing: -0.5rem;
    transform: skewX(-10deg);
  }
`
const customBefore = `top: calc(50% - 2rem);
right: calc(100% + 1.25rem);
transform: skewX(10deg);
font-weight: normal;
letter-spacing: normal;`
const customAfter = `top: 50%;
left: -1.5rem;
border-color: transparent transparent transparent var(--base-color);
transform: skewX(10deg)`

export const CountNumTop = styled.span`
  color: var(--base-color-green);
  margin: -2rem 0 -0.5rem;
  ${ToolTips}
`
CountNumTop.defaultProps = {
  $direction: "custom",
  customBefore,
  customAfter,
}

export const CountNumBottom = styled.span`
  margin-top: -1.5rem;
  ${ToolTips}
`
CountNumBottom.defaultProps = {
  $direction: "custom",
  customBefore,
  customAfter,
}

export const CountGap = styled.div`
  background: currentColor;
  border-radius: 0.25rem;
  transform: rotate(-20deg);
  width: 80%;
  height: 0.5rem;
`
export const PrintErrorItem = styled(ErrorItem)
PrintErrorItem.defaultProps = { $direction: "left" }

export const NavCover = styled.li`
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;

  div {
    width: 100%;
    height: 100%;
    cursor: not-allowed;
    opacity: 0.6;
    background: #fff;
  }
  ${ToolTips}
`
NavCover.defaultProps = {
  $direction: "left",
  children: <div />,
}
