import React, { memo, useCallback, useContext, useEffect, useLayoutEffect, useRef, useState } from "react"
import { ErrorCtx, PageInfoCtx, PrintListCtx, PrintResultCtx, PrintSelectCtx, QueueHistoryCtx } from "@/states"
import { useButton } from "react-aria"
import { difference } from "@/utils"
import { settingCache } from "@/utils/getCache"
import { addEvent, removeEvent } from "@/apis/handleDevicePrint"
import {
  Wrapper,
  NavMenu,
  NavItem,
  MenuButton,
  CountWrapper,
  CountGap,
  CountNumTop,
  CountNumBottom,
  NavCover,
} from "./PrintNav.elements"
import Error from "../Error/Error"

const PrintProgress = memo((props) => {
  const { select } = useContext(PrintSelectCtx)
  const { printResult } = useContext(PrintResultCtx)

  const { tube: tubeSelect, label: labelSelect } = select
  const { tube: tubePrint, label: labelPrint } = printResult

  return (
    <CountWrapper>
      <CountNumTop
        css={`
          font-size: ${tubeSelect.length > 9 ? "4rem" : "5.5rem"};
          ${labelPrint.succeed.length > 9 && "margin-top: -1rem;"}
        `}
        data-tip="采血管打印进度">{`${tubePrint.succeed.length}/${tubeSelect.length}`}</CountNumTop>
      <CountGap />
      <CountNumBottom
        css={`
          font-size: ${labelSelect.length > 9 ? "4rem" : "5.5rem"};
          ${labelPrint.succeed.length > 9 && "margin-top: -0.5rem;"}
        `}
        data-tip="标签打印进度">{`${labelPrint.succeed.length}/${labelSelect.length}`}</CountNumBottom>
    </CountWrapper>
  )
})
PrintProgress.displayName = "PrintProgress"

const PrintCount = memo((props) => {
  const { printList } = useContext(PrintListCtx)
  const { select } = useContext(PrintSelectCtx)

  return (
    <CountWrapper>
      <CountNumTop data-tip="已选项目">{select.size}</CountNumTop>
      <CountGap />
      <CountNumBottom data-tip="全部项目">{printList.length}</CountNumBottom>
    </CountWrapper>
  )
})
PrintCount.displayName = "PrintCount"

const PrintButton = memo((props) => {
  const { select } = useContext(PrintSelectCtx)
  const { setCurrStatus } = useContext(PageInfoCtx)

  const buttonRef = useRef()
  const { buttonProps } = useButton(
    {
      onPress: () => {
        setCurrStatus("printing")
      },
      isDisabled: !select.size,
      type: "submit",
    },
    buttonRef
  )

  return (
    <MenuButton form="print-select-form" primary $main="green" ref={buttonRef} {...buttonProps}>
      打印
    </MenuButton>
  )
})
PrintButton.displayName = "PrintButton"

const LabelPrintButton = memo((props) => {
  const { select } = useContext(PrintSelectCtx)
  const { setCurrStatus } = useContext(PageInfoCtx)

  const buttonRef = useRef()
  const { buttonProps } = useButton(
    {
      onPress: () => {
        setCurrStatus("printing")
      },
      isDisabled: !select.size,
      type: "submit",
    },
    buttonRef
  )

  return (
    <MenuButton
      form="print-select-form"
      primary={false}
      $main="green"
      ref={buttonRef}
      {...buttonProps}
      formAction={`${settingCache.general.device}/api/reprint`}>
      补打
    </MenuButton>
  )
})
LabelPrintButton.displayName = "LabelPrintButton"

const SelectAllButton = memo((props) => {
  const { printList } = useContext(PrintListCtx)
  const { select, setCurrSelect } = useContext(PrintSelectCtx)

  const clear = select.size === printList.length
  const currSelect = clear ? [] : printList.map((item) => item.barcode)

  const buttonRef = useRef()
  const { buttonProps } = useButton(
    {
      onPress: () => setCurrSelect(currSelect),
    },
    buttonRef
  )

  return (
    <MenuButton {...buttonProps} ref={buttonRef}>
      {clear ? "清除" : "全选"}
    </MenuButton>
  )
})
SelectAllButton.displayName = "SelectAllButton"

const UnselectAllButton = memo((props) => {
  const { setCurrSelect } = useContext(PrintSelectCtx)
  const { printList } = useContext(PrintListCtx)

  const buttonRef = useRef()
  const { buttonProps } = useButton(
    {
      onPress: () => {
        setCurrSelect((prevSelect) =>
          difference(
            printList.map((item) => item.id),
            prevSelect
          )
        )
      },
    },
    buttonRef
  )

  return (
    <MenuButton {...buttonProps} ref={buttonRef}>
      反选
    </MenuButton>
  )
})
UnselectAllButton.displayName = "UnselectAllButton"

function PrintNav(props) {
  const { pageStatus, setCurrStatus } = useContext(PageInfoCtx)
  const { setCurrPrintResult } = useContext(PrintResultCtx)
  const { addCurrError } = useContext(ErrorCtx)
  const { addQueueHistory } = useContext(QueueHistoryCtx)

  const pending = pageStatus === "pending"

  useLayoutEffect(() => {
    const resultCache = new Set()
    const allSettledStyle = (size) => {
      const list = document.querySelector(`#print-select-form ul`)
      Array.from(list.children).forEach((elm) => elm.removeAttribute("style"))
      if (size > 1) {
        list.style.animation = "blink 0.6s linear"
        list.addEventListener(
          "animationend",
          () => {
            list.removeAttribute("style")
          },
          { once: true }
        )
      }
    }
    const getPrintProgress = (event) => {
      const list = document.querySelector(`#print-select-form ul`)
      const placeHolder = list.children[0]

      const { type, data } = JSON.parse(event.data)
      if (type === "error") {
        addCurrError({ source: "server", message: data.message })
        return
      }
      const { allSettled, queueNum, id, size, ...result } = data
      const { barcode, type: printType, status } = result

      if (status === "printing") {
        list.style.marginTop = 0
        placeHolder.style.height = `${placeHolder.nextElementSibling?.clientHeight ?? 0}px`
        placeHolder.style.gridColumnStart = -2
      } else {
        resultCache.add(result)
      }
      if (status === "failed") {
        addCurrError({ source: "print", message: `${printType === "tube" ? "采血管" : "标签"}: "${barcode}"打印失败` })
      }

      if (allSettled) {
        setCurrStatus("executed")
        allSettledStyle(size)
        addQueueHistory(queueNum, resultCache, size)
        resultCache.clear()
      }
      setCurrPrintResult(result)
    }
    addEvent("message", getPrintProgress)

    return () => {
      removeEvent("message", getPrintProgress)
    }
  }, [addCurrError, setCurrPrintResult, addQueueHistory, setCurrStatus])

  return (
    <Wrapper>
      {pending ? <PrintCount /> : <PrintProgress />}
      <Error
        range={{ from: 0, to: 2 }}
        direction="left"
        css={`
          width: 9rem;
          flex-basis: 10rem;
          flex-direction: column;
          align-items: center;

          button:first-of-type {
            transform: rotate(90deg);
          }
          button:last-of-type {
            transform: rotate(-90deg);
          }

          ul {
            margin: 0 0 auto;
            flex-direction: column-reverse;
            max-height: 30rem;
            svg {
              animation-name: bounce-in-bottom;
            }
          }
        `}
      />
      <NavMenu
        css={`
          position: relative;
          flex-direction: column;
          margin-top: auto;
          height: unset;
        `}>
        <NavItem>
          <PrintButton />
        </NavItem>
        <NavItem>
          <LabelPrintButton />
        </NavItem>
        <NavItem>
          <SelectAllButton />
        </NavItem>
        <NavItem>
          <UnselectAllButton />
        </NavItem>
        {!pending && <NavCover data-tip="点击底部“重打”按钮，进行重新选择" />}
      </NavMenu>
    </Wrapper>
  )
}

export default memo(PrintNav)
