import React from "react"

function PrintCount({ selected, total }) {
  return (
    <div
      css={`
        font-size: 7.5rem;
        text-align: right;
        width: 100%;
      `}>
      <div>{selected}</div>
      <div
        css={`
          background: currentColor;
          border-radius: 0.25rem;
          transform: rotate(-15deg);
          width: 100%;
          height: 0.5rem;
        `}
      />
      <div>{total}</div>
    </div>
  )
}

export default PrintCount
