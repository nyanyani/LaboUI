import styled from "styled-components"

export const DialogUnderlay = styled.div`
  position: absolute;
  z-index: 100;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #00000066;
`
export const DialogWrapper = styled.div`
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  justify-content: space-between;
  padding: 2rem;
  border: 0.5rem;
  border-radius: 2rem;
  background-color: #fff;
  font-size: 2rem;
  min-width: 40rem;
  min-height: 20rem;
  overflow: hidden;
`

export const DialogTitle = styled.h2`
  margin: 0;
  font-size: 2.5rem;
  user-select: none;
  text-align: left;
`
export const DialogContent = styled.div``
export const ControllerWrapper = styled.div`
  display: flex;
  justify-content: flex-end;
  height: 4rem;
  gap: 3rem;
`

export { Button as DialogOpenBtn } from "@/globalStyles"
