import React, { memo, ReactNode, useCallback, useRef, useState, DetailedReactHTMLElement } from "react"
import { FocusScope, OverlayContainer, useButton, useDialog, useModal, useOverlay, usePreventScroll } from "react-aria"
import styles from "./Dialog.module.scss"

import Button from "../Button/Button"

const Dialog: React.FC<{ title: string; onClose?: () => void; isOpen: boolean; isDismissable: boolean }> = memo(
  (props) => {
    const { title, children, onClose } = props
    const dialogRef = useRef(null)
    const { overlayProps, underlayProps } = useOverlay(props, dialogRef)

    usePreventScroll()
    const { modalProps } = useModal()

    const { dialogProps, titleProps } = useDialog({ ...props, role: "dialog" }, dialogRef)
    const mergeProps = useCallback((child) => React.cloneElement(child, { onClose }), [onClose])

    return (
      <div className={styles.dialog__underlay} {...underlayProps}>
        <FocusScope contain autoFocus restoreFocus>
          <div ref={dialogRef} {...overlayProps} {...dialogProps} {...modalProps}>
            <div {...titleProps}>{title}</div>
            {React.Children.map(children, mergeProps)}
          </div>
        </FocusScope>
      </div>
    )
  }
)
Dialog.displayName = "Dialog"

const DialogTrigger: React.FC<{ label: string }> = memo((props) => {
  const { label, children, ...rest } = props
  const [isOpen, setOpen] = useState(false)

  const openBtnRef = useRef(null)
  const { buttonProps: openBtnProps } = useButton({ onPress: () => setOpen(true) }, openBtnRef)

  return (
    <>
      <Button {...rest} {...openBtnProps} ref={openBtnRef}>
        {label}
      </Button>
      {isOpen && (
        <OverlayContainer>
          {React.Children.map(children, (child) =>
            React.cloneElement(child as React.ReactElement, { isOpen, onClose: () => setOpen(false) })
          )}
        </OverlayContainer>
      )}
    </>
  )
})
DialogTrigger.displayName = "DialogTrigger"

const Controller: React.FC<{ onConfirm?: () => void; onClose?: (type: string) => void; cancelable?: boolean }> = memo(
  (props) => {
    const { onConfirm: confirm, onClose: close, cancelable } = props
    const confirmBtnRef = useRef(null)
    const cancelBtnRef = useRef(null)

    const { buttonProps: cancelBtnProps } = useButton(
      { onPress: () => close && close("cancel"), isDisabled: !cancelable },
      cancelBtnRef
    )
    const { buttonProps: confirmBtnProps } = useButton(
      {
        onPress: () => {
          if (typeof confirm === "function") {
            confirm()
          }
          close && close("confirm")
        },
      },
      confirmBtnRef
    )
    return (
      <div>
        <Button primary $width="10rem" {...confirmBtnProps} ref={confirmBtnRef}>
          确认
        </Button>
        <Button $width="10rem" {...cancelBtnProps} ref={cancelBtnRef}>
          取消
        </Button>
      </div>
    )
  }
)
Controller.displayName = "Controller"

const ButtonTrigger: React.FC<{ label: string; title: string; onClose: () => void }> = memo((props) => {
  const { label, title, children, onClose: close } = props

  return (
    <>
      <DialogTrigger label={label}>
        <Dialog title={title} isOpen isDismissable>
          {children}
          <Controller />
        </Dialog>
      </DialogTrigger>
    </>
  )
})
ButtonTrigger.displayName = "ButtonTrigger"

export { Dialog as default, ButtonTrigger, DialogTrigger, Controller, Button }
