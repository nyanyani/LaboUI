import { Container } from "./Layout.elements"
import { Sidebar } from "../Sidebar/Sidebar"

function Layout() {
  return (
    <>
      <Row>
        <Column>
          <Sidebar />
        </Column>
        <Column>
          <Container />
        </Column>
        <Column>
          <Toolbar />
        </Column>
      </Row>
    </>
  )
}

export default Layout
