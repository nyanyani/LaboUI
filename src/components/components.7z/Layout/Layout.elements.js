import styled from "styled-components"

export const Flex = styled.div`
  display: flex;
`
export const FlexRow = styled.div``

export const FlexColumn = styled.div``

export const Grid = styled.div`
  display: grid;

  ${({ $rows, $cols }) => `
    ${$rows && `grid-template-rows: repeat(${$rows}, 1fr [row-start]);`}
    ${$cols && `grid-template-columns: repeat(${$cols}, 1fr [col-start]);`}
  `}
`
export const GridItem = styled.div`
  ${({ $area, $gridColumnStart, $gridRowStart }) => `
    ${$area && `grid-area: ${$area};`}
    ${$gridColumnStart && `grid-column-start: col-start ${$gridColumnStart};`}
    ${$gridRowStart && `grid-row-start: col-start ${$gridRowStart};`}
  `}
`
